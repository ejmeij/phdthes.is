<?
Header( "Location: http://www.facebook.com/album.php?aid=2111545&id=1244346063&l=48b54197e1" );
phdHeader( "HTTP/1.1 301 Moved Permanently" );
?> 